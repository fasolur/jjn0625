# Prompt Log

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
设置规则：从现在开始，所有CSS类名，id名、js变量都以jjn_开始，所有的提示词都在执行之前写入文件jjn_prompt.md，以附加的方式写入，不覆盖之前的内容，写入的内容包括时间、使用的模型、提示词内容。
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
设置规则：所有新建的html文件加入超链接入口到首页index.html
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
使用当前目录下skills文件夹中的frontend-design skill做两个html网页iconfont-1.html,inconfont-2.html，使得页面具有艺术品牌的样式。分别显示font awesome图标和lucide图标，前者使用字体图标的方式，后者使用svg的方式，相关的cdn文件下载到本目录下的cdn目录。
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
好的，执行吧
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
根据font目录中的iconfont图标完成移动端的固定的自适应宽度的下导航，导航项目包括4个，完成html网页的设计，网页名称iconfont-3.html和iconfont-4.html分别使用字体图标和svg，包括右上角的数字徽章和红点。
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
创建skill:提交项目：使用git commit并push到gitee仓库，
gitee私人令牌 3dc0c06b807f224c48e80a4bbd1a8086;
仓库地址`https://gitee.com/neusoft_wangyao_jsj/hueningkai.git`
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
提交项目到 gitee
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
好的，我去终端执行 push 命令
```

---

**时间**: 2026-10-23
**模型**: Trae (proprietary model from Trae team)
**提示词**:
```
好的，执行吧
```

---

**时间**: 2026-10-23
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
你帮我push
```

---

**时间**: 2026-10-23
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
所以重申一下我需要做的内容
```

---

**时间**: 2026-10-30
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
创建技能skill：提交到github，将本项目提交commit并push到`https://gitee.com/fasolur/jjn0625.git`，使用已设置公钥。
```

---

**时间**: 2026-10-30
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
创建技能skill：提交到github，将本项目提交commit并push到`https://github.com/fasolur/jjn0625`，使用已设置公钥。
```

---

**时间**: 2026-11-04
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
我这个上次搞完了吗
```

---

**时间**: 2026-11-04
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
需要 那个准确率高就用哪个
```

---

**时间**: 2026-11-04
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
我想把这个wy名字改成jjn
```

---

**时间**: 2026-11-04
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
修改规则文件AGENTS.md，在新建html文件时加入注释，注释包括：冀佳宁，建立时间，使用大模型，功能名称。在js部分函数加上函数主要实现功能的注释。 这是我们老师要求的提示词 但我没有在文件找到agents.md 为什么
```

---

**时间**: 2026-11-04
**模型**: DeepSeek-V4.1-Flash
**提示词**:
```
先补齐现有文件的注释
```
